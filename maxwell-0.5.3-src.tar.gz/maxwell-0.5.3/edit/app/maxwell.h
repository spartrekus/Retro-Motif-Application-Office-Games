/*
 *  This file is part of the Maxwell Word Processor application.
 *  Copyright (C) 1996, 1997, 1998 Andrew Haisley, David Miller, Tom Newton
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#ifndef MAXWELL_H
#define MAXWELL_H

#include <X11/Intrinsic.h>
#include <mx.h>
#include <mx_config.h>

#ifndef MX_MAXWELL_VERSION
#ifdef BUILD_RELEASE
#define MX_MAXWELL_VERSION "Maxwell/WP v0.5.3"
#else
#define MX_MAXWELL_VERSION "Maxwell/WP v0.5.3 debug build"
#endif
#endif

extern Widget            global_top_level;
extern XtAppContext      global_app_context;

extern mx_config        *global_user_config;
extern char             *global_maxhome;

#endif
