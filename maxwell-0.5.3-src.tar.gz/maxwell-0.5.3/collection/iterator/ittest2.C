/*
 *  This file is part of the Maxwell Word Processor application.
 *  Copyright (C) 1996, 1997, 1998 Andrew Haisley, David Miller, Tom Newton
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */


#include "dictionary.h"   
#include "mx_iterator.h"   

main()
{
   dictionary  t(mx_string,mx_string) ;

   iterator    it(&t) ;

   mx_attribute_value v,k ;
   mx_attribute_value av,ak ;

   char *key[] =  {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"} ;
   char *data[] = {"a1","b1","c1","d1","e1","f1","g1","h1","i1","j1","k1","l1","m1","n1","o1","p1","q1","r1","s1","t1","u1","v1","w1","x1","y1","z1"} ;

   int nitems = sizeof(key)/sizeof(int)  ;
   int err,data_count ;
   int i,j ;


   for(i=0;i<nitems;i++) 
   {
      v.s = data[i] ;
      k.s = key[i] ;
//      t.check() ;
//      printf("\n") ;
      t.add(err,k,v,data_count) ;
   }

   it.start(err) ;

   k.s = "a" ;
   t.remove(err,k) ;

   it.go(err);


   while(it.next(err,&ak,&av) ) 
   {
      printf("%s %s\n",ak.s,av.s) ; 
   }

   it.start(err) ;

   while(it.next(err,&ak) ) 
   {
      printf("%s \n",ak.s) ; 
   }

   it.setIncrement(FALSE) ;
   it.start(err,mx_it_head) ;

   while(it.next(err,&ak,&av) ) 
   {
      printf("Get back %s %s\n",ak.s,av.s) ; 
   }

   for(i=0;i<nitems;i++) 
   {
      k.s = key[i] ;
      if(t.get(err,k,v)) 
      {
     printf("Get %s %s\n",k.s,v.s) ;
      }
   }

//   t.check() ;
//   printf("\n") ;

   for(i=0;i<nitems;i++) 
   {
      k.s = key[i] ;

      t.remove(err,k) ;
//      t.check() ;
//      printf("\n") ;

//      for(j=0;j<nitems;j++) 
//      {
//     k.i = key[j] ;
//     t.get(err,k,v,data_count) ;
//     if(data_count == 0) 
//     {
//        printf("ugh %d %d\n",k.i,data_count) ;
//     }
//     else
//     {
//        printf("%d %d %d\n",k.i,v.i,data_count) ;
//     }
//      }
//      printf("\n") ;
   }

   printf("End\n") ;
}

