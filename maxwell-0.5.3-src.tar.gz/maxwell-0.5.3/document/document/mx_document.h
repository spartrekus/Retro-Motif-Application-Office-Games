/*
 *  This file is part of the Maxwell Word Processor application.
 *  Copyright (C) 1996, 1997, 1998 Andrew Haisley, David Miller, Tom Newton
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#ifndef MX_DOCUMENT_INC_H
#define MX_DOCUMENT_INC_H

#include <mx_area_pos.h>
#include <mx_para_pos.h>
#include <mx_position.h>
#include <mx_txt_pos.h>
#include <mx_wp_pos.h>
#include <mx_break_w.h>
#include <mx_complex_w.h>
#include <mx_field_w.h>
#include <mx_paragraph.h>
#include <mx_simple_w.h>
#include <mx_space_w.h>
#include <mx_word.h>
#include <mx_font.h>
#include <mx_bd_style.h>
#include <mx_char_style.h>
#include <mx_colour.h>
#include <mx_spline.h>
#include <mx_doc_coord.h>
#include <mx_doc_rect.h>
#include <mx_line_style.h>
#include <mx_para_style.h>
#include <mx_ruler.h>
#include <mx_sizes.h>
#include <mx_style.h>
#include <mx_area.h>
#include <mx_dg_area.h>
#include <mx_image_area.h>
#include <mx_table_area.h>
#include <mx_text_area.h>
#include <mx_document.h>
#include <mx_sheet.h>
#include <mx_wp_doc.h>

#endif
