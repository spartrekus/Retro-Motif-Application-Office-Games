/*
 *  This file is part of the Maxwell Word Processor application.
 *  Copyright (C) 1996, 1997, 1998 Andrew Haisley, David Miller, Tom Newton
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <mx.h>
//#include <mx_std.h>
//#include <mx_error.h>
#include <mx_font.h>
#include <Xm/Xm.h>

// This is a timing test
// get_width is called loads when reformatting - currently it's bloody slow
// this test is to see if it can be speeded up

char * global_maxhome = "/usr/local/maxwell";
Widget global_top_level;

int main(void)
{
    int err = MX_ERROR_OK;
    mx_font f(err, "Adobe-Utopia");

    MX_ERROR_CHECK(err);

    for (int i = 0; i < 40000; i++)
    {
        f.width("ASmallBrownFoxJumpedOverTheZeroWidthCollieDog");
    }
    return 0;
abort:
    global_error_trace->print();
    return 1;
}

