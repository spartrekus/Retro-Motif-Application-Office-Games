/*
 *  This file is part of the Maxwell Word Processor application.
 *  Copyright (C) 1996, 1997, 1998 Andrew Haisley, David Miller, Tom Newton
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#ifndef MX_UI_H
#define MX_UI_H

#include <mx_ui_object.h>
#include <mx_bar.h>
#include <mx_menubar.h>
#include <mx_stsbar.h>
#include <mx_wp_menu_items.h>
#include <mx_wp_menubar.h>
#include <mx_wp_stsbar.h>
#include <mx_wp_toolbar.h>
#include <mx_window.h>
#include <mx_dialog.h>
#include <mx_about_d.h>
#include <mx_border_d.h>
#include <mx_cell_d.h>
#include <mx_char_d.h>
#include <mx_column_d.h>
#include <mx_date_d.h>
#include <mx_dialog_man.h>
#include <mx_env_d.h>
#include <mx_error_d.h>
#include <mx_finfo_d.h>
#include <mx_goto_d.h>
#include <mx_hsearch_d.h>
#include <mx_index_d.h>
#include <mx_inform_d.h>
#include <mx_ins_c_d.h>
#include <mx_ins_r_d.h>
#include <mx_locked_d.h>
#include <mx_lv_d.h>
#include <mx_new_d.h>
#include <mx_open_d.h>
#include <mx_opt_d.h>
#include <mx_page_d.h>
#include <mx_para_d.h>
#include <mx_print_d.h>
#include <mx_printcap.h>
#include <mx_prog_d.h>
#include <mx_quit_d.h>
#include <mx_replace_d.h>
#include <mx_save_d.h>
#include <mx_search_d.h>
#include <mx_spell_d.h>
#include <mx_style_d.h>
#include <mx_support_d.h>
#include <mx_symbol_d.h>
#include <mx_tab_d.h>
#include <mx_table_d.h>
#include <mx_toc_d.h>
#include <mx_valid_d.h>
#include <mx_yes_no_d.h>
#include <mx_zoom_d.h>

#endif
