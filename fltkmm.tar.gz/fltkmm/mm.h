#ifndef MM_H
#define MM_H


#define ABSOLUTE_VALUE(x)  ((x) < 0 ? -(x) : (x))

#define NUM_COLS                4
#define MAX_COLORS              6
#define NUM_ROWS                10

#define RED_BALL                0
#define GREEN_BALL              1
#define BLUE_BALL               2
#define YELLOW_BALL             3
#define CYAN_BALL               4
#define MAGENTA_BALL            5

#define RIGHT_COLOR_RIGHT_POS       1
#define RIGHT_COLOR_WRONG_POS       2
#define WRONG_COLOR_WRONG_POS       3


#define RED_SELECTED            0
#define GREEN_SELECTED          1
#define BLUE_SELECTED           2 
#define YELLOW_SELECTED         3
#define MAGENTA_SELECTED        4
#define CYAN_SELECTED           5

void colSelectCb(int b);
void colSetCb(int p);
void highlightRedBall(void);
void setColorPixmap(void);
void makeCode(void);
void roundButtonArray(void);
void aboutCb(void);
void rulesCb(void);
void resetBoard(void);


#endif /* MM_H */
