#include <stdio.h>
#include <string.h>

#include "ui.h"
#include <FL/fl_ask.H>
#include <FL/Fl_Pixmap.H>

#include <FL/x.H> /* XXX */

#include "bitmaps/red.xpm"
#include "bitmaps/redb.xpm"

#include "bitmaps/green.xpm"
#include "bitmaps/greenb.xpm"

#include "bitmaps/blue.xpm"
#include "bitmaps/blueb.xpm"

#include "bitmaps/cyan.xpm"
#include "bitmaps/cyanb.xpm"

#include "bitmaps/magenta.xpm"
#include "bitmaps/magentab.xpm"

#include "bitmaps/yellow.xpm"
#include "bitmaps/yellowb.xpm"

#include "bitmaps/ques.xpm"
#include "bitmaps/tiny.xpm"

#include "mm.h"

#include <time.h>
#include <stdlib.h> /* for srand */


/* - statics - */
static int
    col_selected=RED_BALL;

static int
    guess_peg[NUM_COLS],
    code_peg[NUM_COLS];

static int
    last_selected=RED_BALL,
    now_selected;

static int
    current_row=0,
    last_row=0,
    last_col=0;

static int
    col_done[NUM_COLS];

Fl_Button
    *round_buttons[NUM_COLS*NUM_ROWS+NUM_COLS];

Fl_Round_Button
    *score_pegs[NUM_COLS*NUM_ROWS+NUM_COLS];

Fl_Box
    *arrows[NUM_ROWS];
/* - statics - */


static Fl_Pixmap pixmap_red(image_red);
static Fl_Pixmap pixmap_redb(image_redb);

static Fl_Pixmap pixmap_green(image_green);
static Fl_Pixmap pixmap_greenb(image_greenb);

static Fl_Pixmap pixmap_blue(image_blue);
static Fl_Pixmap pixmap_blueb(image_blueb);

static Fl_Pixmap pixmap_yellow(image_yellow);
static Fl_Pixmap pixmap_yellowb(image_yellowb);

static Fl_Pixmap pixmap_cyan(image_cyan);
static Fl_Pixmap pixmap_cyanb(image_cyanb);

static Fl_Pixmap pixmap_magenta(image_magenta);
static Fl_Pixmap pixmap_magentab(image_magentab);

static Fl_Pixmap pixmap_ques(image_ques);
static Fl_Pixmap pixmap_tiny(image_tiny);


/*
**  doBeep()
**      beep
**
**  Parameters:
**      none
**
**  Return Values:
**      none
**
**  Limitations and Comments:
**      for Unix and Win32
**
**  Development History:
**      who                  when           why
**      muquit@muquit.com   May-17-2001     first cut
*/
static void doBeep(void)
{
#ifdef WIN32
            MessageBeep(MB_ICONERROR);
#else /* UNIX */
            if (!fl_display)
                fl_open_display();
            if (fl_display)
                XBell(fl_display, 100);
            else
            {
                printf("\007"); /* doesn't work in windoze */
                (void) fflush(stdout);
            }
#endif /* UNIX */
    return;
}

void roundButtonArray(void)
{
    int
        i;

    round_buttons[0]=r0c0;
    round_buttons[1]=r0c1;
    round_buttons[2]=r0c2;
    round_buttons[3]=r0c3;

    round_buttons[4]=r1c0;
    round_buttons[5]=r1c1;
    round_buttons[6]=r1c2;
    round_buttons[7]=r1c3;

    round_buttons[8]=r2c0;
    round_buttons[9]=r2c1;
    round_buttons[10]=r2c2;
    round_buttons[11]=r2c3;

    round_buttons[12]=r3c0;
    round_buttons[13]=r3c1;
    round_buttons[14]=r3c2;
    round_buttons[15]=r3c3;

    round_buttons[16]=r4c0;
    round_buttons[17]=r4c1;
    round_buttons[18]=r4c2;
    round_buttons[19]=r4c3;

    round_buttons[20]=r5c0;
    round_buttons[21]=r5c1;
    round_buttons[22]=r5c2;
    round_buttons[23]=r5c3;

    round_buttons[24]=r6c0;
    round_buttons[25]=r6c1;
    round_buttons[26]=r6c2;
    round_buttons[27]=r6c3;

    round_buttons[28]=r7c0;
    round_buttons[29]=r7c1;
    round_buttons[30]=r7c2;
    round_buttons[31]=r7c3;

    round_buttons[32]=r8c0;
    round_buttons[33]=r8c1;
    round_buttons[34]=r8c2;
    round_buttons[35]=r8c3;

    round_buttons[36]=r9c0;
    round_buttons[37]=r9c1;
    round_buttons[38]=r9c2;
    round_buttons[39]=r9c3;

    for (i=0; i < NUM_COLS*NUM_ROWS; i++)
    {
        pixmap_tiny.label(round_buttons[i]);
    }


/* score pegs */
    score_pegs[0]=sr0c0;
    score_pegs[1]=sr0c1;
    score_pegs[2]=sr0c2;
    score_pegs[3]=sr0c3;

    score_pegs[4]=sr1c0;
    score_pegs[5]=sr1c1;
    score_pegs[6]=sr1c2;
    score_pegs[7]=sr1c3;

    score_pegs[8]=sr2c0;
    score_pegs[9]=sr2c1;
    score_pegs[10]=sr2c2;
    score_pegs[11]=sr2c3;

    score_pegs[12]=sr3c0;
    score_pegs[13]=sr3c1;
    score_pegs[14]=sr3c2;
    score_pegs[15]=sr3c3;

    score_pegs[16]=sr4c0;
    score_pegs[17]=sr4c1;
    score_pegs[18]=sr4c2;
    score_pegs[19]=sr4c3;

    score_pegs[20]=sr5c0;
    score_pegs[21]=sr5c1;
    score_pegs[22]=sr5c2;
    score_pegs[23]=sr5c3;

    score_pegs[24]=sr6c0;
    score_pegs[25]=sr6c1;
    score_pegs[26]=sr6c2;
    score_pegs[27]=sr6c3;

    score_pegs[28]=sr7c0;
    score_pegs[29]=sr7c1;
    score_pegs[30]=sr7c2;
    score_pegs[31]=sr7c3;

    score_pegs[32]=sr8c0;
    score_pegs[33]=sr8c1;
    score_pegs[34]=sr8c2;
    score_pegs[35]=sr8c3;

    score_pegs[36]=sr9c0;
    score_pegs[37]=sr9c1;
    score_pegs[38]=sr9c2;
    score_pegs[39]=sr9c3;


    arrows[0]=arrow0;
    arrows[1]=arrow1;
    arrows[2]=arrow2;
    arrows[3]=arrow3;
    arrows[4]=arrow4;
    arrows[5]=arrow5;
    arrows[6]=arrow6;
    arrows[7]=arrow7;
    arrows[8]=arrow8;
    arrows[9]=arrow9;
}

void setColorPixmap(void)
{

    pixmap_red.label(red);
    pixmap_green.label(green);
    pixmap_blue.label(blue);
    pixmap_yellow.label(yellow);
    pixmap_cyan.label(cyan);
    pixmap_magenta.label(magenta);

    pixmap_ques.label(hidden0);
    pixmap_ques.label(hidden1);
    pixmap_ques.label(hidden2);
    pixmap_ques.label(hidden3);

}

void highlightRedBall(void)
{
    pixmap_redb.label(red);
}

void resetBoard(void)
{
    int
        i;

    colSelectCb(RED_BALL);
    last_selected=RED_BALL;
    current_row=0;

    makeCode();
    pixmap_ques.label(hidden0);
    pixmap_ques.label(hidden1);
    pixmap_ques.label(hidden2);
    pixmap_ques.label(hidden3);

    for (i=0; i < NUM_COLS*NUM_ROWS; i++)
    {
        pixmap_tiny.label(round_buttons[i]);
        score_pegs[i]->color(49);
        score_pegs[i]->selection_color(49);
    }

    for (i=0; i < NUM_ROWS; i++)
        arrows[i]->hide();

    arrows[0]->show();


    main_window->redraw();
}

static void revealTheCode(void)
{
    int
        i,
        peg;

    Fl_Button
        *b;

    hidden0->active();
    hidden1->active();
    hidden2->active();
    hidden3->active();

    for (i=0; i < NUM_COLS; i++)
    {
        if (i == 0)
        {
            b=hidden0;
            peg=code_peg[0];
        }
        else if (i == 1)
        {
            b=hidden1;
            peg=code_peg[1];
        }
        else if (i == 2)
        {
            b=hidden2;
            peg=code_peg[2];
        }
        else
        {
            b=hidden3;
            peg=code_peg[3];
        }

        switch (peg)
        {
            case RED_BALL:
            {
                pixmap_red.label(b);
                break;
            }

            case GREEN_BALL:
            {
                pixmap_green.label(b);
                break;
            }

            case BLUE_BALL:
            {
                pixmap_blue.label(b);
                break;
            }

            case YELLOW_BALL:
            {
                pixmap_yellow.label(b);
                break;
            }

            case CYAN_BALL:
            {
                pixmap_cyan.label(b);
                break;
            }

            case MAGENTA_BALL:
            {
                pixmap_magenta.label(b);
                break;
            }
        }
    }

}

void scoreTheRow(void)
{
    int
        i,
        j,
        rc_rp,
        rc_wp,
        prev_row;

    int
        score_peg_start=0,
        guess_pos[NUM_COLS],
        code_pos[NUM_COLS];

    rc_rp=0;
    rc_wp=0;


    prev_row=current_row-1;

    for (i=0; i < NUM_COLS; i++)
    {
        guess_pos[i]=code_pos[i]=WRONG_COLOR_WRONG_POS;
    }

    for (i=0; i < NUM_COLS; i++)
    {
        if (guess_peg[i] == code_peg[i])
        {
            guess_pos[i]=code_pos[i]=RIGHT_COLOR_RIGHT_POS;
            rc_rp++;
        }
    }

    if (rc_rp != NUM_COLS)
    {
        for (i=0; i < NUM_COLS; i++)
        {
            for (j=0; j < NUM_COLS; j++)
            {
                if (guess_peg[i] == code_peg[j]           &&
                    code_pos[j] == WRONG_COLOR_WRONG_POS  &&
                    guess_pos[i] == WRONG_COLOR_WRONG_POS)
                {
                    guess_pos[i]=code_pos[j]=RIGHT_COLOR_WRONG_POS;
                    rc_wp++;
                }
            }
        }
    }

    score_peg_start=(current_row-1) * NUM_COLS;
    if (score_peg_start < 0)
        score_peg_start=0;
    for (i=0; i < rc_rp; i++)
    {
        score_pegs[score_peg_start]->color(FL_BLACK);
        score_pegs[score_peg_start]->selection_color(FL_BLACK);
        score_peg_start++;
    }
    for (i=0; i < rc_wp; i++)
    {
        score_pegs[score_peg_start]->color(FL_WHITE);
        score_pegs[score_peg_start]->selection_color(FL_WHITE);
        score_peg_start++;
    }

    if (rc_rp == NUM_COLS)
    {
        int
            score_col=current_row-1;
        char
            buf[BUFSIZ];

        doBeep();
        revealTheCode();
        (void) sprintf(buf,"Congratulations!\nYou found the code in %d moves\nPlay again?",current_row);
        if (fl_ask(buf))
        {
            resetBoard();
        }
        else
            exit(0);
    }
    else if (current_row == NUM_ROWS)
    {
        doBeep();
        doBeep();
        revealTheCode();

        if (fl_ask("Sorry You could not solve the puzzle!\nTry again?"))
        {
            resetBoard();
        }
        else
            exit(0);
    }
}

/* callback for select color at the top of the window */
void colSelectCb(int b)
{
    now_selected=b;

    if (last_selected == now_selected)
        return;

    /* erase the selected box */
    switch (last_selected)
    {
        case RED_BALL:
        {
            pixmap_red.label(red);
            break;
        }

        case GREEN_BALL:
        {
            pixmap_green.label(green);
            break;
        }

        case BLUE_BALL:
        {
            pixmap_blue.label(blue);
            break;
        }

        case YELLOW_BALL:
        {
            pixmap_yellow.label(yellow);
            break;
        }

        case CYAN_BALL:
        {
            pixmap_cyan.label(cyan);
            break;
        }

        case MAGENTA_BALL:
        {
            pixmap_magenta.label(magenta);
            break;
        }
    }
    last_selected=b;

    switch (now_selected)
    {
        case RED_BALL:
        {
            pixmap_redb.label(red);
            break;
        }

        case GREEN_BALL:
        {
            pixmap_greenb.label(green);
            break;
        }

        case BLUE_BALL:
        {
            pixmap_blueb.label(blue);
            break;
        }

        case YELLOW_BALL:
        {
            pixmap_yellowb.label(yellow);
            break;
        }

        case CYAN_BALL:
        {
            pixmap_cyanb.label(cyan);
            break;
        }

        case MAGENTA_BALL:
        {
            pixmap_magentab.label(magenta);
            break;
        }
    } 
    main_window->redraw();
}


/* callback routine for round buttons */
void colSetCb(int p) {

    int
        col,
        clicked_row,
        clicked_col;

    Fl_Button
        *b;


    clicked_row=p/NUM_COLS;
    clicked_col=p;

#ifdef DEBUG
    (void) fprintf(stderr,"b(%d,%d)\n",clicked_row,clicked_col);
#endif /* DEBUG */


    if (clicked_row != current_row)
    {
        return;
    }

    b=round_buttons[p];
    col_done[clicked_col % NUM_COLS]=1;

#ifdef DEBUG
    (void) fprintf(stderr," clicked_col % NUM_COLS=%d,code=%d\n",
                   (clicked_col % NUM_COLS),now_selected);
#endif /* DEBUG */

    guess_peg[clicked_col % NUM_COLS]=now_selected;

    switch (now_selected)
    {
        case RED_BALL:
        {
            pixmap_red.label(b);
            break;
        }

        case GREEN_BALL:
        {
            pixmap_green.label(b);
            break;
        }

        case BLUE_BALL:
        {
            pixmap_blue.label(b);
            break;
        }

        case YELLOW_BALL:
        {
            pixmap_yellow.label(b);
            break;
        }

        case CYAN_BALL:
        {
            pixmap_cyan.label(b);
            break;
        }

        case MAGENTA_BALL:
        {
            pixmap_magenta.label(b);
            break;
        }
    }

    if (col_done[0] == 1 && 
        col_done[1] == 1 &&
        col_done[2] == 1 &&
        col_done[3] == 1)
    {
        col_done[0]=0;
        col_done[1]=0;
        col_done[2]=0;
        col_done[3]=0;

        arrows[clicked_row]->hide();
        if (clicked_row <= NUM_ROWS)
        {
            clicked_row++;
            current_row++;
        }
        if (clicked_row < NUM_ROWS)
            arrows[clicked_row]->show();
        scoreTheRow();
    }
}


void makeCode(void)
{
    int
        col,
        tmp;

    time_t
        t;

    t=time(NULL);
    srand(t);
    for (col=0; col < NUM_COLS; col++)
    {
        code_peg[col]=rand() % MAX_COLORS;
#ifdef DEBUG
        (void) fprintf(stderr," code=%d\n",code_peg[col]);
#endif /* DEBUG */
    }


}

void aboutCb(void)
{
    static Fl_Window
        *about_window=NULL;
    const char *about_msg=
"fltkmm 1.1\n"
"(for Linux/Unix and MS Windows)\n"
"by\n"
"Muhammad A Muquit\n"
"http://www.muquit.com/muquit/software/\n"
"muquit@muquit.com";

    if (about_window == NULL)
    {
        about_window=new Fl_Window(300,100,"About fltkmm");
        Fl_Box
            *o=new Fl_Box(2, 2, 296,96,about_msg);
        o->box(FL_THIN_DOWN_BOX);
        o->color(7);
        o->labelfont(4);
        o->labelsize(12);
        o->align(FL_ALIGN_TOP|FL_ALIGN_INSIDE);
//        about_window->resizable(about_window);
        about_window->hotspot(about_window);
        about_window->end();
    }
    about_window->position(main_window->x()+main_window->w()+10,
                main_window->y());
    about_window->show();
}

void rulesCb(void)
{
    rules_window->position(main_window->x()+main_window->w()+10,
                main_window->y());
    rules_window->show();
}
