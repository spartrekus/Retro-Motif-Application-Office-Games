#!/bin/sh
#
# muquit, Jul-30-1999
#

pwd=`pwd`
pwd_head=`basename $pwd`
file='fltkmm'

#
# first check if we'r at the corrent directory
#

if [ $pwd_head != fltkmm ]; then
    echo "You are in wrong base directory"
    echo "Expected: ldap"
    echo "Found:    $pwd_head"
    echo "exiting ..."
    exit 1
fi



tar_filename=$file.tar
#
# remove the tar file if any in the current working directoyr
#
if [ -f ./$tar_filename.gz ]; then
    echo "removing $tar_filename.gz"
    rm -f ./$tar_filename.gz
fi

make clean > /dev/null 2>&1
#
# go up
#

cd ..
tar -cf /tmp/$tar_filename_$$ ./$pwd_head
if [ $? -eq 0 ]; then
    gzip -f -v -9 /tmp/$tar_filename_$$
    mv /tmp/$tar_filename_$$.gz ./$pwd_head/$tar_filename.gz
    cd $pwd
    /bin/ls -l $tar_filename.gz
fi
