/* 
 * callbacks.h --
 *
 *      This file contains the declaration of the functions from
 *      the callbacks.c file.
 *
 * Copyright (C) 1996  Carlos Nunes - loscar@mime.univ-paris8.fr
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */


#ifndef CALLBACKS_H
#define CALLBACKS_H

void command_CB(Widget, XtPointer, XtPointer);

void iconBar_CB(Widget, XtPointer, XtPointer);
void optionMenu_CB(Widget, XtPointer, XtPointer);

void menu_p0_b0_CB(Widget, XtPointer, XtPointer);
void menu_p0_b1_CB(Widget, XtPointer, XtPointer);
void menu_p0_b2_CB(Widget, XtPointer, XtPointer);
void menu_p0_b4_CB(Widget, XtPointer, XtPointer);
void menu_p0_b5_CB(Widget, XtPointer, XtPointer);
void menu_p0_b6_CB(Widget, XtPointer, XtPointer);

void menu_p2_b0_CB(Widget, XtPointer, XtPointer);

void menu_p3_b0_CB(Widget, XtPointer, XtPointer);
void menu_p3_b1_CB(Widget, XtPointer, XtPointer);
void menu_p3_b3_CB(Widget, XtPointer, XtPointer);

void menu_p4_b0_CB(Widget, XtPointer, XtPointer);
void menu_p4_b1_CB(Widget, XtPointer, XtPointer);
void menu_p4_b3_CB(Widget, XtPointer, XtPointer);
void menu_p4_b4_CB(Widget, XtPointer, XtPointer);
void menu_p4_b5_CB(Widget, XtPointer, XtPointer);
void menu_p4_b6_CB(Widget, XtPointer, XtPointer);

void menu_p5_b3_CB(Widget, XtPointer, XtPointer);

void printerDevice_CB(Widget, XtPointer, XtPointer);
void filePrintSearch_CB(Widget, XtPointer, XtPointer);
void fontSelect_CB(Widget, XtPointer, XtPointer);

void command_CB(Widget, XtPointer, XtPointer);

void open_CB(Widget, XtPointer, XtPointer);
void save_CB(Widget, XtPointer, XtPointer);
void search_CB(Widget, XtPointer, XtPointer);

void infos_CB(Widget, XtPointer, XtPointer);
void quit_CB(Widget, XtPointer, XtPointer);

void params_CB(Widget, XtPointer, XtPointer);
void paraParams_CB(Widget, XtPointer, XtPointer);

void saveFormat_CB(Widget, XtPointer, XtPointer);

void print_CB(Widget, XtPointer, XtPointer);
void printOrient_CB(Widget, XtPointer, XtPointer);
void printFormat_CB(Widget, XtPointer, XtPointer);
void printDevice_CB(Widget, XtPointer, XtPointer);

void CenterDialog_CB(Widget, XtPointer, XtPointer);

void specialChars_select_CB(Widget, XtPointer, XtPointer);
void specialChars_insert_CB(Widget, XtPointer, XtPointer);
void specialChars_cancel_CB(Widget, XtPointer, XtPointer);

void error_CB(Widget, XtPointer, XtPointer);
void question_CB(Widget, XtPointer, XtPointer);

void fieldItem_CB(Widget, XtPointer, XtPointer);
void ispell_CB(Widget, XtPointer, XtPointer);
void ispellList_CB(Widget, XtPointer, XtPointer);
void ispellClose_CB(Widget , XtPointer, XtPointer);
void documentInfo_CB(Widget, XtPointer, XtPointer);


#endif
